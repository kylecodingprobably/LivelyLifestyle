package com.example.livelylifestyle;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageButton;

import java.io.IOException;
import java.io.OutputStreamWriter;

/**
 * Plan to select the level on endurance for the user
 * Multiple levels
 * Matthew
 */
public class Endurance extends AppCompatActivity {

    /**
     * Upon create sets layout and puts buttons
     * @param savedInstanceState
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ninth);

        configureBackButton();
        configureBeginnerPlanButton();
        configureIntermediatePlanButton();
        configureAdvancedPlanButton();
    }

    private void configureBackButton() {
        ImageButton BackButton = (ImageButton) findViewById(R.id.BackButton);
        BackButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        }
        );
    }

    private void configureBeginnerPlanButton() {
        ImageButton BeginnerPlanButton = (ImageButton) findViewById(R.id.BeginnerPlanButton);
        BeginnerPlanButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                myUtils.appendToFile("beginner",getBaseContext());
                startActivity(new Intent(Endurance.this, homeScreen.class));
            }
        }
        );
    }

    private void configureIntermediatePlanButton() {
        ImageButton IntermediatePlanButton = (ImageButton) findViewById(R.id.IntermediatePlanButton);
        IntermediatePlanButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                myUtils.appendToFile("intermediate",getBaseContext());
                startActivity(new Intent(Endurance.this, homeScreen.class));
            }
        }
        );
    }

    private void configureAdvancedPlanButton() {
        ImageButton AdvancedPlanButton = (ImageButton) findViewById(R.id.AdvancedPlanButton);
        AdvancedPlanButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                myUtils.appendToFile("advanced",getBaseContext());
                startActivity(new Intent(Endurance.this, homeScreen.class));
            }
        }
        );
    }
}