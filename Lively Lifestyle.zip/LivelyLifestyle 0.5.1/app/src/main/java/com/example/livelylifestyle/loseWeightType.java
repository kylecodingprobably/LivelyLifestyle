package com.example.livelylifestyle;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageButton;

import java.io.IOException;
import java.io.OutputStreamWriter;

public class loseWeightType extends AppCompatActivity {

    private void writeToFile(String data, Context context) {
        try {
            OutputStreamWriter outputStreamWriter = new OutputStreamWriter(context.openFileOutput("plan.txt", Context.MODE_APPEND));
            outputStreamWriter.append(data).append("\n");
            outputStreamWriter.close();
        }
        catch (IOException e) {
            Log.e("Exception", "File write failed: " + e.toString());
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_eleventh);

        configureBackButton();
        configureBeginnerPlanButtonThree();
        configureIntermediatePlanButtonThree();
        configureAdvancedPlanButtonThree();
    }

    private void configureBackButton() {
        ImageButton BackButton = (ImageButton) findViewById(R.id.BackButton);
        BackButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        }
        );
    }

    private void configureBeginnerPlanButtonThree() {
        ImageButton BeginnerPlanButtonThree = (ImageButton) findViewById(R.id.BeginnerPlanButtonThree);
        BeginnerPlanButtonThree.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                writeToFile("beginner",getBaseContext());
                startActivity(new Intent(loseWeightType.this, homeScreen.class));
            }
        }
        );
    }

    private void configureIntermediatePlanButtonThree() {
        ImageButton IntermediatePlanButtonThree = (ImageButton) findViewById(R.id.IntermediatePlanButtonThree);
        IntermediatePlanButtonThree.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                writeToFile("intermediate",getBaseContext());
                startActivity(new Intent(loseWeightType.this, homeScreen.class));
            }
        }
        );
    }

    private void configureAdvancedPlanButtonThree() {
        ImageButton AdvancedPlanButtonThree = (ImageButton) findViewById(R.id.AdvancedPlanButtonThree);
        AdvancedPlanButtonThree.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                writeToFile("advanced",getBaseContext());
                startActivity(new Intent(loseWeightType.this, homeScreen.class));
            }
        }
        );
    }
}