package com.example.livelylifestyle;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageButton;

import java.io.IOException;
import java.io.OutputStreamWriter;

public class gainMuscle extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_seventh);

        configureBackButton();
        configureRegularPlanButton();
        configureCleanBulkPlanButton();
        configureDirtyBulkPlanButton();
    }

    private void configureBackButton() {
        ImageButton BackButton = (ImageButton) findViewById(R.id.BackButton);
        BackButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
    }

    private void configureRegularPlanButton() {
        ImageButton RegularPlanButton = (ImageButton) findViewById(R.id.RegularPlanButton);
        RegularPlanButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                myUtils.appendToFile("regular",getBaseContext());
                startActivity(new Intent(gainMuscle.this, gainMuscleType.class));
            }
        });
    }

    private void configureCleanBulkPlanButton() {
        ImageButton CleanBulkPlanButton = (ImageButton) findViewById(R.id.CleanBulkPlanButton);
        CleanBulkPlanButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                myUtils.appendToFile("cleanBulk",getBaseContext());
                startActivity(new Intent(gainMuscle.this, gainMuscleType.class));
            }
        });
    }

    private void configureDirtyBulkPlanButton() {
        ImageButton DirtyBulkPlanButton = (ImageButton) findViewById(R.id.DirtyBulkPlanButton);
        DirtyBulkPlanButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                myUtils.appendToFile("dirtyBulk",getBaseContext());
                startActivity(new Intent(gainMuscle.this, gainMuscleType.class));
            }
        });
    }
}